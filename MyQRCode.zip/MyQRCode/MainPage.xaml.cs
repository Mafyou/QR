﻿using QRCoder;

namespace MyQRCode;

public partial class MainPage : ContentPage
{
    public MainPage()
    {
        InitializeComponent();
    }

    private void OnCounterClicked(object sender, EventArgs e)
    {
        // Existing counter logic
    }

    private void OnGenerateQrClicked(object sender, EventArgs e)
    {
        var text = inputEntry.Text;
        if (string.IsNullOrWhiteSpace(text))
        {
            imageQRCode.Source = null;
            return;
        }

        // Generate QR code as PNG
        using (var qrGenerator = new QRCodeGenerator())
        using (var qrCodeData = qrGenerator.CreateQrCode(text, QRCodeGenerator.ECCLevel.Q))
        using (var qrCode = new PngByteQRCode(qrCodeData))
        {
            var qrCodeBytes = qrCode.GetGraphic(20);
            imageQRCode.Source = ImageSource.FromStream(() => new MemoryStream(qrCodeBytes));
        }
    }
}
